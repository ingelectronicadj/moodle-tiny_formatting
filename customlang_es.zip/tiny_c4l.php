<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from https://campus112.unad.edu.co/aut04
 *
 * @package    tiny
 * @subpackage c4l
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['additionalhtml'] = 'HTML adicional';
$string['aimedatstudents'] = 'Dirigido a estudiantes';
$string['aimedatstudents_desc'] = 'De forma predeterminada, solo los componentes seleccionados estarán disponibles para los usuarios con capacidades de estudiante cuando utilicen el editor. Para cambiar la configuración predeterminada, simplemente marque o desmarque su selección preferida.';
$string['align-center'] = 'Alinear al centro';
$string['align-left'] = 'Alinear a la izquierda';
$string['align-right'] = 'Alinear a la derecha';
$string['allpurposecard'] = 'Tarjeta multiuso';
$string['attention'] = 'Atención';
$string['button_c4l'] = 'Componentes visuales';
$string['c4l:viewplugin'] = 'Ver el complemento C4L';
$string['caption'] = 'Subtítulo';
$string['comfort-reading'] = 'Lectura reconfortante';
$string['contextual'] = 'Contextual';
$string['custom'] = 'Personalizar';
$string['customcompcode'] = 'Componente de código HTML {$a}';
$string['customcompcodedesc'] = 'La palabra <code>{{CUSTOMCLASS}}</code> es una clase obligatoria que debe estar junto a las clases CSS de sus componentes principales. <br /> Ejemplo de código: <pre> <div class="{{CUSTOMCLASS}} <!-- Agregue sus clases CSS principales aquí -->"> <p>{{PLACEHOLDER}}</p> </div> </pre> Tenga en cuenta que cualquier código Javascript o CSS en línea se eliminará antes de la representación.';
$string['customcompcount'] = 'Número de componentes personalizados';
$string['customcompcountdesc'] = 'Número de componentes personalizados que se crearán';
$string['customcompenable'] = 'Habilitar componente {$a}';
$string['customcompenabledesc'] = 'Si está habilitado, este componente estará disponible.';
$string['customcompicon'] = 'Componente de icono {$a}';
$string['customcompicondesc'] = 'Componente de icono opcional. Tamaño recomendado: 18 x 18 píxeles.';
$string['customcompname'] = 'Componente de texto del botón {$a}';
$string['customcompnamedesc'] = 'Texto mostrado dentro del botón.';
$string['customcomponents'] = 'Componentes personalizados';
$string['customcompsortorder'] = 'Componente de orden de clasificación {$a}';
$string['customcompsortorderdesc'] = 'Establece la posición del componente en la interfaz de usuario.';
$string['customcomptext'] = 'Componente de texto de marcador de posición {$a}';
$string['customcomptextdesc'] = 'Texto que se mostrará como marcador de posición en el componente. Inserte la palabra <code>{{PLACEHOLDER}}</code> en el código.';
$string['customcomptitle'] = 'Componente personalizado {$a}';
$string['customcompvariant'] = 'Habilitar componente de variantes {$a}';
$string['customcompvariantdesc'] = 'Si está habilitado, la variante de ancho completo estará disponible para este componente.';
$string['customimagesbank'] = 'Banco de imágenes';
$string['customimagesbankdesc'] = 'Para insertar cualquiera de las imágenes cargadas en su código, agregue esta línea:<br /> <code><img src="{{filename.extension}}" alt="Imagen personalizada"></code>';
$string['custompreviewcss'] = 'Código CSS';
$string['custompreviewcssdesc'] = 'CSS utilizado para obtener una vista previa de los componentes dentro del editor. <p>Cualquier código CSS agregado aquí también debe incluirse en su tema o dentro de las etiquetas de estilo <code><style>...<style></code> y guardarse en la configuración <strong>additionalhtmlhead</strong> en {$a}; de lo contrario, sus estilos no se aplicarán a sus componentes cuando se procesen.</p>';
$string['do-card'] = 'Hacer tarjeta';
$string['dodontcards'] = 'Hacer/No hacer tarjeta';
$string['dont-card-only'] = 'No solo tarjeta';
$string['duedate'] = 'Fecha de vencimiento';
$string['enablepreview'] = 'Habilitar vista previa';
$string['enablepreview_desc'] = 'Si está habilitado, se muestra una vista previa cuando pasa el cursor del mouse sobre cada componente.';
$string['estimatedtime'] = 'Tiempo estimado';
$string['evaluative'] = 'Evaluativo';
$string['example'] = 'Ejemplo';
$string['expectedfeedback'] = 'Retroalimentación esperada';
$string['figure'] = 'Cifra';
$string['full-width'] = 'Ancho completo';
$string['generalsettings'] = 'General';
$string['gradingvalue'] = 'Valor de calificación';
$string['helper'] = 'Auxiliar';
$string['helplinktext'] = 'Ayudante C4L';
$string['inlinetag'] = 'Etiqueta en línea';
$string['keyconcept'] = 'Concepto clave';
$string['learningoutcomes'] = 'Resultados del aprendizaje';
$string['menuitem_c4l'] = 'Componentes para el aprendizaje (C4L)';
$string['notintendedforstudents'] = 'No destinado a estudiantes';
$string['notintendedforstudents_desc'] = 'De manera predeterminada, los componentes evaluativos y procedimentales no están pensados ​​para que los utilicen los usuarios con capacidades de estudiante en el editor. Para cambiar la configuración predeterminada, marque los componentes que desea poner a disposición de los estudiantes.';
$string['ordered-list'] = 'Artículos pedidos';
$string['pluginname'] = 'Componentes para el aprendizaje (C4L)';
$string['preview'] = 'Previsualización';
$string['previewdefault'] = 'Coloque el puntero sobre cualquier componente para ver su vista previa.';
$string['privacy:preference:components_variants'] = 'Variantes preferidas de cada componente';
$string['procedural'] = 'Procedimiento';
$string['proceduralcontext'] = 'Contexto procesal';
$string['quote'] = 'Cita';
$string['readingcontext'] = 'Contexto de lectura';
$string['reminder'] = 'Recordatorio';
$string['tag'] = 'Etiqueta';
$string['textplaceholder'] = 'El cliente es muy importante, el cliente será seguido por el cliente.';
$string['tip'] = 'Consejo';
