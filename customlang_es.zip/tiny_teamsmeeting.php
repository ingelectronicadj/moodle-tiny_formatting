<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from https://campus112.unad.edu.co/aut04
 *
 * @package    tiny
 * @subpackage teamsmeeting
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['iframe_go_to_meeting'] = 'Ir a la reunión';
$string['iframe_meeting_created'] = '¡La reunión "{$a}" se creó exitosamente!';
$string['iframe_meeting_options'] = 'Opciones de reunión';
$string['iframe_not_found'] = 'Reunión no encontrada';
$string['pluginname'] = 'Reunión de equipos';
$string['privacy:metadata'] = 'El complemento Tiny Teams Meeting no almacena ningún dato personal';
$string['privacy:metadata:msteamsapp'] = 'El complemento Tiny Teams Meeting no almacena ningún dato. Sin embargo, envía el código de idioma del usuario a la aplicación Microsoft Teams para proporcionar una interfaz de usuario basada en el idioma del usuario.';
$string['privacy:metadata:msteamsapp:userlang'] = 'Código de idioma del usuario enviado a la aplicación Microsoft Teams.';
$string['settings_meetings_app_link_desc'] = 'Esta es la URL de la ubicación de la aplicación de reuniones';
$string['teamsmeeting:add'] = 'Agregar reunión de Teams';
$string['tiny_button_primary_label'] = 'Añadir enlace';
$string['tiny_button_secondary_label'] = 'Cancelar';
$string['tiny_checkbox_new_window_label'] = 'Abrir reunión en nueva ventana';
$string['tiny_input_url_label'] = 'URL de su reunión:';
$string['tiny_input_url_placeholder'] = 'El enlace se generará después de crear la reunión.';
$string['tiny_modal_title'] = 'Crear una reunión de Teams';
