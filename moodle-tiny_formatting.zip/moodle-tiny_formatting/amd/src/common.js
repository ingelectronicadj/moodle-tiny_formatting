export default {
    component: 'tiny_formatting',
    pluginName: 'tiny_formatting/formatting',
};
