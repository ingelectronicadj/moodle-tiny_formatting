# TinyMCE Formatting for Moodle

This is an example of how you may add and manage the TinyMCE configuration from within your own plugin.

This example adds back the native TinyMCE text formatting features.

Please note that this is an example and is _not maintained_. It is intended to give you an insight into how different configuration may be achieved.
